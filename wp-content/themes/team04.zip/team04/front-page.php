
<?php get_header(); ?>



<?php include("inc/heroimage.inc") ?>



<?php include("indexdata.php") ?>



  <?php get_footer(); ?>
